#.First.lib <- function(libname, package) {
#  library.dynam("ExomeDepth", package)
#}

.onLoad <- function(lib, pkg) {
 #library.dynam("ExomeDepth", package)
}
